# Class LinCombineLayerA

**Module import path**: `Q_Sea_Battle.lin_combine_layer_a.LinCombineLayerA`

> Maps PR-assisted outcomes to communication logits.

!!! note "Parent class"
    Inherits from `tf.keras.layers.Layer`.

## Overview

Produces logits of shape `(m,)` or `(B, m)`.

## Changelog

- 2026-01-11 — Author: Technical Documentation Team
