"""Smoke test mirroring Tutorial_LinTrainableAssisted_Imitation notebook.

This test is intentionally fast and deterministic:
- No training loops.
- No tournaments.
- Only import/construct objects and run a single forward pass.

It validates that the tutorial's public imports and minimal interfaces work.
"""

from __future__ import annotations

import inspect

import numpy as np
import tensorflow as tf

from Q_Sea_Battle.game_env import GameEnv  # noqa: F401  (import parity with notebook)
from Q_Sea_Battle.game_layout import GameLayout
from Q_Sea_Battle.lin_teacher_layers import (
    LinCombineLayerA,
    LinCombineLayerB,
    LinMeasurementLayerA,
    LinMeasurementLayerB,
)
from Q_Sea_Battle.lin_trainable_assisted_imitation_utilities import (
    generate_combine_dataset_a,
    generate_combine_dataset_b,
    generate_measurement_dataset_a,
    generate_measurement_dataset_b,
    to_tf_dataset,
    train_layer,  # noqa: F401  (import parity with notebook)
    transfer_assisted_model_a_layer_weights,
    transfer_assisted_model_b_layer_weights,
)
from Q_Sea_Battle.lin_trainable_models import LinTrainableAssistedModelA, LinTrainableAssistedModelB
from Q_Sea_Battle.tournament import Tournament  # noqa: F401  (import parity with notebook)
from Q_Sea_Battle.trainable_assisted_players import TrainableAssistedPlayers  # noqa: F401


def _try_construct_layer(layer_cls, field_size: int, comms_size: int):
    """Best-effort construction for teacher-layer primitives.

    Some layers may accept no args, others may accept layout parameters.
    """

    sig = inspect.signature(layer_cls)
    kwargs = {}
    if "field_size" in sig.parameters:
        kwargs["field_size"] = field_size
    if "comms_size" in sig.parameters:
        kwargs["comms_size"] = comms_size
    try:
        return layer_cls(**kwargs)
    except TypeError:
        return layer_cls()


def test_tutorial_lin_trainable_assisted_imitation_smoke_runs():
    tf.random.set_seed(123)
    np.random.seed(123)

    # Minimal layout consistent with the tutorial.
    field_size = 4
    comms_size = 1
    n2 = field_size * field_size

    layout = GameLayout(field_size=field_size, comms_size=comms_size)

    # Dataset utilities: generate tiny datasets to validate callability.
    ds_meas_a = generate_measurement_dataset_a(layout, num_samples=4, seed=123)
    ds_comb_a = generate_combine_dataset_a(layout, num_samples=4, seed=124)
    ds_meas_b = generate_measurement_dataset_b(layout, num_samples=4, seed=125)
    ds_comb_b = generate_combine_dataset_b(layout, num_samples=4, seed=126)

    _ = to_tf_dataset(ds_meas_a, x_keys=["field"], y_key="meas_target", batch_size=2, shuffle=False, seed=123)
    _ = to_tf_dataset(ds_comb_a, x_keys=["outcomes_a"], y_key="comm_target", batch_size=2, shuffle=False, seed=123)
    _ = to_tf_dataset(ds_meas_b, x_keys=["gun"], y_key="meas_target", batch_size=2, shuffle=False, seed=123)
    _ = to_tf_dataset(ds_comb_b, x_keys=["outcomes_b", "comm"], y_key="shoot_target", batch_size=2, shuffle=False, seed=123)

    # Teacher-layer primitives: instantiate (best-effort).
    _ = _try_construct_layer(LinMeasurementLayerA, field_size, comms_size)
    _ = _try_construct_layer(LinCombineLayerA, field_size, comms_size)
    _ = _try_construct_layer(LinMeasurementLayerB, field_size, comms_size)
    _ = _try_construct_layer(LinCombineLayerB, field_size, comms_size)

    # Trainable models (no training): one forward pass.
    model_a = LinTrainableAssistedModelA(
        field_size=field_size,
        comms_size=comms_size,
        sr_mode="sample",
        seed=123,
        p_high=1.0,
    )
    model_b = LinTrainableAssistedModelB(
        field_size=field_size,
        comms_size=comms_size,
        sr_mode="sample",
        seed=123,
        p_high=1.0,
    )

    B = 2
    field = tf.zeros((B, n2), dtype=tf.float32)
    gun = tf.one_hot(tf.zeros((B,), dtype=tf.int32), depth=n2, dtype=tf.float32)

    comm_out = model_a(field)
    assert isinstance(comm_out, tf.Tensor)
    assert comm_out.dtype == tf.float32
    assert tuple(comm_out.shape) == (B, comms_size)

    prev_meas_list = [tf.zeros((B, n2), dtype=tf.float32)]
    prev_out_list = [tf.zeros((B, n2), dtype=tf.float32)]
    shoot_out = model_b([gun, comm_out, prev_meas_list, prev_out_list])

    assert isinstance(shoot_out, tf.Tensor)
    assert shoot_out.dtype == tf.float32
    assert tuple(shoot_out.shape) in {(B, n2), (B, 1)}

    # Weight transfer helpers should be callable after building the models.
    _ = model_a(tf.zeros((1, n2), tf.float32))
    _ = model_b(
        [
            tf.zeros((1, n2), tf.float32),
            tf.zeros((1, comms_size), tf.float32),
            [tf.zeros((1, n2), tf.float32)],
            [tf.zeros((1, n2), tf.float32)],
        ]
    )
    transfer_assisted_model_a_layer_weights(model_a.measure_layer, model_a.combine_layer, model_a)
    transfer_assisted_model_b_layer_weights(model_b.measure_layer, model_b.combine_layer, model_b)
